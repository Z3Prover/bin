gcc -o test_capi -I ../../include -L ../../lib -lz3-gmp test_capi.c
