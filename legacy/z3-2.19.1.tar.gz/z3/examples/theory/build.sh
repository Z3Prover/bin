gcc -o test_user_theory -I ../../include -L ../../lib -lz3-gmp test_user_theory.c
