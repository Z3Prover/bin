gcc -o maxsat -I ../../include -L ../../lib -lz3-gmp maxsat.c
